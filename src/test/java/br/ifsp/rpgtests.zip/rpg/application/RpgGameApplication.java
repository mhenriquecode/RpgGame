package br.ifsp.rpg.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RpgGameApplication {
    public static void main(String[] args) {
        SpringApplication.run(RpgGameApplication.class, args);
    }
}
