package br.ifsp.rpg.suites;

import org.junit.platform.suite.api.IncludeTags;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.platform.suite.api.Suite;
import org.junit.platform.suite.api.SuiteDisplayName;

@Suite
@SelectPackages({"br.edu.ifsp.rpg"}) // A tag does not include test classes by itself.
@SuiteDisplayName("All unit tests")
@IncludeTags({"TDD"})
public class TDD {
}
